Kulili - Collect all dots with minimum moves

http://popelkapavel.sweb.cz/kulili/kulili.htm

Keys 
  
  PgUp,Enter - next level
  PgDown - previous level
  Backspace - previous/reset level
  numpad digits - level number
  F11,Alt+Enter,Control+Enter - switch fullscreen
  Q,Up - up
  A,Down - down
  O,Left - left
  P,Right - right

  X,F4 - mirror x
  Y,Z,F5 - mirror y

mouse
  left button - move to cursor
  double click ball  - swtich fullscreen
   