Kulili - Collect all dots with minimum moves

https://popelkapavel.github.io/kulili/

Keys 
  
  PgUp,Enter - next level
  PgDown - previous level
  Backspace - previous/reset level
  numpad digits - level number
  F11,Alt+Enter,Control+Enter - switch fullscreen
  Q,Up - up
  A,Down - down
  O,Left - left
  P,Right - right

  X,F4 - mirror x
  Y,Z,F5 - mirror y
  T - show game time
  C - show clocks

mouse
  left button - move to cursor
  double click ball  - switch fullscreen

command line
  kulili.exe [levels_file.txt]   
  -o : solo, without enemy
  -d : dual, control both balls
  -a : autopilot off
  -F : draw order sequence of 0,1,2 letters
  -f : draw full before up image (-F 012)
  -i dir : image dictionary
  -l dir : level dictionary
  -h : help
